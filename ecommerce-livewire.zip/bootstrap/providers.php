<?php

return [
    App\Providers\AppServiceProvider::class,
    Gloudemans\Shoppingcart\ShoppingcartServiceProvider::class
];
