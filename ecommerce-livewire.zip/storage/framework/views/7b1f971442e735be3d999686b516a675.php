<div>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home')); ?>" rel="nofollow" wire:navigate>Accueil</a>
                    <span></span> Boutique
                    <span></span> Votre Panier
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <!--[if BLOCK]><![endif]--><?php if(Cart::instance('cart')->count() > 0): ?>

                    <div class="row">
                        <div class="col-lg-8 col-md-12">
                            <div class="table-responsive">
                                <table class="table shopping-summery text-center clean">
                                    <thead>
                                        <tr class="main-heading">
                                            <th scope="col">Image</th>
                                            <th scope="col">Nom</th>
                                            <th scope="col">Prix</th>
                                            <th scope="col">Quantité</th>
                                            <th scope="col">Total</th>
                                            <th scope="col">Supprimer</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="image product-thumbnail"><img src="<?php echo e($row->model->image); ?>" alt="#"></td>
                                                <td class="product-des product-name">
                                                    <h5 class="product-name"><a href="<?php echo e(route('details', ['slug' => $row->model->slug])); ?>"><?php echo e($row->model->name); ?></a>
                                                        <div>
                                                            <!--[if BLOCK]><![endif]--><?php if($row->options->color): ?>
                                                            <span class="text-muted">Couleur : <?php echo e(ucwords($row->options->color)); ?></span>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            <!--[if BLOCK]><![endif]--><?php if($row->options->size): ?>
                                                            <span class="text-muted">Taille : <?php echo e($row->options->size); ?></span>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        </div>
                                                    </h5>
                                                </td>
                                                <td class="price" data-title="Price"><span>$<?php echo e($row->price); ?> </span></td>

                                                <td class="text-center" data-title="Stock">
                                                    <div class="quantity-field" >
                                                        <button
                                                          class="value-button decrease-button"
                                                          wire:click.prevent="reduceQuantityToCart('<?php echo e($row->rowId); ?>')">-</button>
                                                          <div class="number"><?php echo e($row->qty); ?></div>
                                                        <button
                                                          class="value-button increase-button"
                                                          wire:click.prevent="addQuantityToCart('<?php echo e($row->rowId); ?>')">+
                                                        </button>
                                                      </div>
                                                </td>
                                                <td class="text-right" data-title="Cart">
                                                    <span>$<?php echo e($row->subtotal()); ?> </span>
                                                </td>
                                                <td class="action" data-title="Remove"><a class="text-muted"
                                                    wire:click.prevent="removeToCart('<?php echo e($row->rowId); ?>')"><i class="fi-rs-trash"></i></a></td>
                                            </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <tr>
                                            <td colspan="6" class="text-end">
                                                <a class="text-muted" wire:click.prevent='destroyCart()'> <i class="fi-rs-cross-small"></i> Vider le panier</a>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="cart-action text-end">
                                <a href="<?php echo e(route('shop')); ?>" class="btn "><i class="fi-rs-shopping-bag mr-10"></i>Continuer l'achat</a>
                            </div>

                        </div>
                        <div class="col-lg-4 col-md-12">
                            <div class="border p-md-4 p-30 border-radius cart-totals">
                                <div class="heading_s1 mb-3">
                                    <h4>Total Panier</h4>
                                </div>
                                <div class="table-responsive">
                                    <!--[if BLOCK]><![endif]--><?php if(session()->has('coupon')): ?>
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="cart_total_label">Sous-total</td>
                                                    <td class="cart_total_amount"><span class="font-lg fw-900 text-brand">$<?php echo e(number_format(Cart::instance('cart')->subtotal(), 2)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Réduction (<?php echo e(session()->get('coupon')['coupon_code']); ?>)</td>
                                                    <td class="cart_total_amount"><span class="font-lg fw-900 text-brand">-$<?php echo e(number_format($discount, 2)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Sous-total après réduction</td>
                                                    <td class="cart_total_amount"><span class="font-lg fw-900 text-brand">$<?php echo e(number_format($subtotalAfterDiscount, 2)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Tax</td>
                                                    <td class="cart_total_amount"><span class="font-lg fw-900 text-brand">$<?php echo e(number_format($taxAfterDiscount, 2)); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Livraison</td>
                                                    <td class="cart_total_amount"> <i class="ti-gift mr-5"></i> Livraison Gratuite</td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Total</td>
                                                    <td class="cart_total_amount"><strong><span class="font-xl fw-900 text-brand">$<?php echo e(number_format($totalAfterDiscount, 2)); ?></span></strong></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    <?php else: ?>

                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                    <td class="cart_total_label">Sous-total</td>
                                                    <td class="cart_total_amount"><span class="font-lg fw-900 text-brand">$<?php echo e(Cart::subtotal()); ?></span></td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Livraison</td>
                                                    <td class="cart_total_amount"> <i class="ti-gift mr-5"></i> Livraison Gratuite</td>
                                                </tr>
                                                <tr>
                                                    <td class="cart_total_label">Total</td>
                                                    <td class="cart_total_amount"><strong><span class="font-xl fw-900 text-brand">$<?php echo e(Cart::total()); ?></span></strong></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <!--[if BLOCK]><![endif]--><?php if(!session()->has('coupon')): ?>

                                    <div class="mb-20 mt-10">
                                        <div class="total-amount">
                                            <div class="left">
                                                <div class="coupon">
                                                    <form action="#" target="_blank">
                                                        <div class="form-row row justify-content-center">
                                                            <div class="form-group col-lg-7">
                                                                <input class="font-medium" name="Coupon" wire:model.defer='couponCode' placeholder="Entrer votre Coupon">
                                                            </div>
                                                            <div class="form-group col-lg-5">
                                                                <button class="btn  btn-sm" type="submit" wire:click.prevent='upplyCoupon'><i class="fi-rs-label mr-10"></i>Appliquer</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <a class="btn w-100" href="<?php echo e(route('checkout')); ?>" wire:navigate> <i class="fi-rs-box-alt mr-10"></i> Procéder au paiement</a>
                            </div>
                        </div>
                    </div>

                <?php else: ?>
                <div class="card">
                    <div class="card-body text-center">

                        <h4>Aucun produit trouvé dans votre panier</h4>
                        <p class=" mt-2"><i class="fi-rs-shopping-cart" style="font-size: 700%"></i></p>
                    </div>
                </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="divider center_icon mt-20 mb-20 col-lg-12 col-md-12" ><i class="fi-rs-fingerprint"></i></div>
                <h3 class="section-title mb-20"><span>Autres produits</span> qui peuvent vous intéresser</h3>
                <div class="row product-grid-2">
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="col-lg-2 col-md-4 col-6 col-sm-6 g-2">
                            <div class="product-cart-wrap mb-20">
                                <div class="product-img-action-wrap">
                                    <div class="product-img product-img-zoom">
                                        <a href="<?php echo e(route('details', ['slug' => $product->slug])); ?>"  wire:navigate>
                                            <img class="default-img" src="<?php echo e($product->image); ?>" alt="">
                                            <img class="hover-img" src="assets/imgs/shop/product-2-2.jpg" alt="">
                                        </a>
                                    </div>
                                    <div class="product-badges product-badges-position product-badges-mrg">
                                        <span class="hot">Hot</span>
                                    </div>
                                </div>
                                <div class="product-content-wrap">
                                    <div class="product-category">
                                        <a href="shop.html">Music</a>
                                    </div>
                                    <h2><a href="product-details.html"><?php echo e($product->name); ?></a></h2>
                                    <div class="rating-result" title="90%">
                                        <span>
                                            <span>90%</span>
                                        </span>
                                    </div>
                                    <div class="product-price">
                                        <span>$<?php echo e($product->sale_price); ?> </span>
                                        <span class="old-price">$<?php echo e($product->regular_price); ?></span>
                                    </div>
                                    <div class="product-action-1 show">
                                        <a aria-label="Ajouter au panier" class="action-btn hover-up" wire:click.prevent="addToCart('<?php echo e($product->id); ?>','<?php echo e(addslashes($product->name)); ?>', 1, <?php echo e($product->sale_price); ?>)"><i class="fi-rs-shopping-bag-add"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <h5>Aucun produit trouvé</h5>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/cart-component.blade.php ENDPATH**/ ?>