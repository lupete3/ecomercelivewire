<div class="card">

    <div class="card-header">
        <div class="shop-product-fillter mb-0">
            <div class="totall-product">
                <div class="sidebar-widget widget_search">
                    <div class="search-form">
                        <form action="">
                            <input type="search" name="search" wire:model.live='search' id="" placeholder="Rechercher........">
                            <button type="submit"><i class="fi-rs-search"></i></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="sort-by-product-area">
                <div class="sort-by-cover mr-10">
                    <div class="sort-by-product-wrap">
                        <div class="sort-by">
                            <span><i class="fi-rs-apps"></i>Voir:</span>
                        </div>
                        <div class="sort-by-dropdown-wrap">
                            <span> <?php echo e($ordersPerPage); ?> <i class="fi-rs-angle-small-down"></i></span>
                        </div>
                    </div>
                    <div class="sort-by-dropdown">
                        <ul>
                            <li><a class="<?php echo e($ordersPerPage == 10 ? 'active' : ''); ?>" wire:click.prevent='changeOrdersPerPage(10)'>10</a></li>
                            <li><a class="<?php echo e($ordersPerPage == 20 ? 'active' : ''); ?>" wire:click.prevent='changeOrdersPerPage(20)'>20</a></li>
                            <li><a class="<?php echo e($ordersPerPage == 30 ? 'active' : ''); ?>" wire:click.prevent='changeOrdersPerPage(30)'>30</a></li>
                            <li><a class="<?php echo e($ordersPerPage == 40 ? 'active' : ''); ?>" wire:click.prevent='changeOrdersPerPage(40)'>40</a></li>
                            <li><a class="<?php echo e($ordersPerPage == 60 ? 'active' : ''); ?>" wire:click.prevent='changeOrdersPerPage(60)'>60</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card-body table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nom</th>
                    <th>Téléphone</th>
                    <th>Ville</th>
                    <th>Adresse</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr wire:key="order-<?php echo e($order->id); ?>">
                        <td><?php echo e($index + $orders->firstItem()); ?></td>
                        <td><?php echo e($order->name); ?></td>
                        <td><?php echo e($order->phone); ?></td>
                        <td><?php echo e($order->city); ?></td>
                        <td><?php echo e($order->adress); ?></td>
                        <td><?php echo e(number_format($order->total, 2)); ?> Fc</td>
                        <td>
                            <?php
                                $statusList = [
                                    'ordered' => ['label' => 'Commandée', 'class' => 'badge bg-secondary'],
                                    'processing' => ['label' => 'En traitement', 'class' => 'badge bg-warning text-dark'],
                                    'shipped' => ['label' => 'Expédiée', 'class' => 'badge bg-info text-dark'],
                                    'delivered' => ['label' => 'Livrée', 'class' => 'badge bg-success'],
                                    'cancelled' => ['label' => 'Annulée', 'class' => 'badge bg-danger'],
                                ];
                            ?>

                            <span class="<?php echo e($statusList[$order->status]['class']); ?>">
                                <?php echo e($statusList[$order->status]['label']); ?>

                            </span>
                        </td>

                        <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                        <td>
                            <a href="#" class="text-info" wire:click.prevent="showDetails(<?php echo e($order->id); ?>)"> <i class="fi-rs-eye"></i> Détails</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="9" class="text-center">Aucune commande trouvée.</td></tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>

        <?php echo e($orders->links()); ?>

    </div>


    <div class="modal fade" id="orderDetailsModal" tabindex="-1" aria-labelledby="orderDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header bg-warning text-white">
              <h5 class="modal-title">Détails de la commande #<?php echo e($selectedOrder?->id); ?></h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fermer"></button>
            </div>
            <div class="modal-body">

              <!--[if BLOCK]><![endif]--><?php if($selectedOrder): ?>
                  <p><strong>Client :</strong> <?php echo e($selectedOrder->name); ?> | <?php echo e($selectedOrder->phone); ?></p>
                  <p><strong>Adresse :</strong> <?php echo e($selectedOrder->adress); ?>, <?php echo e($selectedOrder->city); ?></p>

                  <table class="table table-bordered mt-3">
                      <thead>
                          <tr>
                              <th>Produit</th>
                              <th>Prix</th>
                              <th>Quantité</th>
                              <th>Sous-total</th>
                          </tr>
                      </thead>
                      <tbody>
                          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedOrder->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                  <td><?php echo e($item->product->name ?? 'Produit supprimé'); ?></td>
                                  <td><?php echo e(number_format($item->price, 2)); ?> €</td>
                                  <td><?php echo e($item->quantity); ?></td>
                                  <td><?php echo e(number_format($item->price * $item->quantity, 2)); ?> €</td>
                              </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                      </tbody>
                  </table>

                  <div class="text-end">
                      <p><strong>Frais de livraison :</strong> <?php echo e(number_format($selectedOrder->shipping_cost, 2)); ?> €</p>
                      <p><strong>Total :</strong> <?php echo e(number_format($selectedOrder->total, 2)); ?> €</p>
                  </div>
                  <div class="d-flex justify-content-between">
                        

                        <!--[if BLOCK]><![endif]--><?php if($selectedOrder): ?>
                            <div class="mb-3">
                                <label class="form-label fw-bold">Statut de la commande :</label>
                                <div class="d-flex gap-3 flex-wrap">
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = [
                                        'ordered' => 'Commandée',
                                        'processing' => 'En traitement',
                                        'shipped' => 'Expédiée',
                                        'delivered' => 'Livrée',
                                        'cancelled' => 'Annulée',
                                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="<?php echo e($selectedOrder->status === $value ? 'active' : ''); ?>">
                                            <input type="radio" wire:click="updateStatus('<?php echo e($value); ?>')" name="status"
                                                value="<?php echo e($value); ?>" <?php echo e($selectedOrder->status === $value ? 'checked' : ''); ?>>
                                            <?php echo e($label); ?>

                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                    </div>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            </div>
          </div>
        </div>
    </div>


</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/admin/orders/orders-component.blade.php ENDPATH**/ ?>