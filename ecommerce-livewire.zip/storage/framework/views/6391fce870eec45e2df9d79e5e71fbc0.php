<main class="main single-page">
    <div class="page-header breadcrumb-wrap">
        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo e(route('home')); ?>" rel="nofollow">Accueil</a>
                <span></span> A propos de nous
            </div>
        </div>
    </div>
    <section class="section-padding">
        <div class="container pt-25">
            <div class="row">
                <div class="col-lg-6 align-self-center mb-lg-0 mb-4">
                    <h6 class="mt-0 mb-15 text-uppercase font-sm text-brand wow fadeIn animated">Notre Organisation</h6>
                    <h1 class="font-heading mb-40">
                        <?php echo e($about->title); ?>

                    </h1>
                    <p><?php echo e($about->description); ?></p>
                </div>
                <div class="col-lg-6">
                    <img src="<?php echo e(asset('/'.$about->image)); ?>" alt="">
                </div>
            </div>
        </div>
    </section>
    
</main>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/about-component.blade.php ENDPATH**/ ?>