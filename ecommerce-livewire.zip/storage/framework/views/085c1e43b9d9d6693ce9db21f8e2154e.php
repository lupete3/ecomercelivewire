<?php echo e($slot); ?>

<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>