<div class="header-action-icon-2">
    <a href="<?php echo e(route('wishlist')); ?>" wire:navigate>
        <img class="svgInject" alt="Surfside Media" src="<?php echo e(asset('assets/imgs/theme/icons/icon-heart.svg')); ?>">
        <span class="pro-count blue"><?php echo e(Cart::instance('wishlist')->count() > 0 ? Cart::instance('wishlist')->count() : 0); ?></span>
    </a>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/wishlisticon-component.blade.php ENDPATH**/ ?>