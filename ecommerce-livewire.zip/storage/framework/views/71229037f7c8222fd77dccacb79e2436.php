<div class="card">
    <div class="card-header">
        <div class="shop-product-fillter mb-0">
            <div class="totall-product">
                <div class="sidebar-widget widget_search">
                    <div class="search-form">
                        <form action="">
                            <input type="search" name="search" wire:model.live='search' placeholder="Rechercher........">
                            <button type="submit"><i class="fi-rs-search"></i></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="sort-by-product-area">
                <div class="sort-by-cover mr-10">
                    <div class="sort-by-product-wrap">
                        <div class="sort-by">
                            <span><i class="fi-rs-apps"></i>Voir:</span>
                        </div>
                        <div class="sort-by-dropdown-wrap">
                            <span> <?php echo e($productPerPage); ?> <i class="fi-rs-angle-small-down"></i></span>
                        </div>
                    </div>
                    <div class="sort-by-dropdown">
                        <ul>
                            <li><a class="<?php echo e($productPerPage == 10 ? 'active' : ''); ?>" wire:click.prevent='changeProductPerPage(10)'>10</a></li>
                            <li><a class="<?php echo e($productPerPage == 20 ? 'active' : ''); ?>" wire:click.prevent='changeProductPerPage(20)'>20</a></li>
                            <li><a class="<?php echo e($productPerPage == 30 ? 'active' : ''); ?>" wire:click.prevent='changeProductPerPage(30)'>30</a></li>
                            <li><a class="<?php echo e($productPerPage == 40 ? 'active' : ''); ?>" wire:click.prevent='changeProductPerPage(40)'>40</a></li>
                            <li><a class="<?php echo e($productPerPage == 60 ? 'active' : ''); ?>" wire:click.prevent='changeProductPerPage(60)'>60</a></li>
                        </ul>
                    </div>
                </div>
                <button class="btn btn-warning btn-sm" wire:click.prevent='showAddSliderModal'>Ajouter</button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Titre de haut</th>
                        <th>Titre principal</th>
                        <th>Sous-titre</th>
                        <th>Offre</th>
                        <th>Image</th>
                        <th>Date Début</th>
                        <th>Date Fin</th>
                        <th>Type</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr wire:key="slider-<?php echo e($slider->id); ?>">
                            <td><?php echo e($index + $sliders->firstItem()); ?></td>
                            <td><?php echo e($slider->top_title); ?></td>
                            <td><?php echo e($slider->title); ?></td>
                            <td><?php echo e($slider->sub_title); ?></td>
                            <td><?php echo e($slider->offer); ?></td>
                            <td><img src="<?php echo e($slider->getImage()); ?>" alt="" width="55px" srcset=""></td>
                            <td><?php echo e($slider->start_date); ?></td>
                            <td><?php echo e($slider->end_date); ?></td>
                            <td><?php echo e($slider->type); ?></td>
                            <td><p class="text-center <?php echo e($slider->status == 1 ? 'bg-3' : 'bg-6'); ?>"><?php echo e($slider->status == 1 ? 'Actif' : 'Inactif'); ?></p></td>
                            <td>
                                <div class="d-flex gap-1">
                                    <i wire:click.prevent='showEditSliderModal(<?php echo e($slider->id); ?>)' class="fi-rs-pencil mr-10 text-info" style="font-size: 16px"></i>
                                    <i wire:click.prevent='sendConfirm(<?php echo e($slider->id); ?>, "warning", "Voulez-vous supprimer ce slider?", "Supprimer")' class="fi-rs-trash" style="font-size: 16px"></i></button>
                                </div>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>

            <?php echo e($sliders->links()); ?>

        </div>
    </div>

    <?php echo $__env->make('livewire.admin.slider.add-slider-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/admin/slider/slider-component.blade.php ENDPATH**/ ?>