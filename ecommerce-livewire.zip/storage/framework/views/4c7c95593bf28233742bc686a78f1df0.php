<div class="header-action-icon-2">
    <a class="mini-cart-icon" href="<?php echo e(route('cart')); ?>">
        <img alt="Surfside Media" src="<?php echo e(asset('assets/imgs/theme/icons/icon-cart.svg')); ?>">
        <span class="pro-count blue">
            <?php echo e(Cart::instance('cart')->count() > 0 ? Cart::instance('cart')->count() : 0); ?>

        </span>
    </a>
    <!--[if BLOCK]><![endif]--><?php if(Cart::instance('cart')->count() > 0): ?>
        <div class="cart-dropdown-wrap cart-dropdown-hm2">
            <ul>
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <li>
                        <div class="shopping-cart-img">
                            <a href="product-details.html"><img alt="Surfside Media" src="<?php echo e(asset($item->model->image)); ?>"></a>
                        </div>
                        <div class="shopping-cart-title">
                            <h4><a href="<?php echo e(route('details', ['slug' => $item->id])); ?>"><?php echo e(ucwords(Str::substr($item->model->name, 0, 15))); ?></a></h4>
                            <h4><span><?php echo e($item->qty); ?> × </span>$<?php echo e($item->model->sale_price); ?></h4>
                        </div>
                        <div class="shopping-cart-delete">
                            <a href="#" wire:click.prevent='removeToCart("<?php echo e($item->rowId); ?>")'><i class="fi-rs-cross-small"></i></a>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>



                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
            <div class="shopping-cart-footer">
                 <div class="shopping-cart-total">
                    <h4>Total <span>$<?php echo e(Cart::total()); ?></span></h4>
                </div>
                <div class="shopping-cart-button">
                    <a href="<?php echo e(route('cart')); ?>" class="outline" wire:navigate>Affichier le panier</a>
                    <a href="<?php echo e(route('checkout')); ?>" wire:navigate>Payer</a>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/carticon-component.blade.php ENDPATH**/ ?>