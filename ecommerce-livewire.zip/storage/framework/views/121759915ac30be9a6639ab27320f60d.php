<div>
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href='<?php echo e(route('product.category', ['slug' => $category->slug])); ?>' wire:navigate><?php echo e($category->name); ?></a></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/menu-categories.blade.php ENDPATH**/ ?>