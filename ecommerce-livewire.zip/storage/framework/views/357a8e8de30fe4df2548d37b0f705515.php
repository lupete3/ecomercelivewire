<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>