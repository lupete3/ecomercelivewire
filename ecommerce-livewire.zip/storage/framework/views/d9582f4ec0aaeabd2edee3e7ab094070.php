<div>
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="<?php echo e(route('home')); ?>" rel="nofollow"  wire:navigate>Accueil</a>
                    <span></span> Shop
                </div>
            </div>
        </div>
        <section class="mt-50 mb-50">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="shop-product-fillter">
                            <div class="totall-product">
                                <p> Nous trouvons <strong class="text-brand"><?php echo e(Cart::instance('wishlist')->count()); ?></strong> produits pour vous!</p>
                            </div>
                            
                        </div>
                        <div class="row product-grid-3">
                            <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = Cart::instance('wishlist')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                <div class="col-lg-3 col-md-3 col-6 col-sm-6">
                                    <div class="product-cart-wrap mb-30">
                                        <div class="product-img-action-wrap">
                                            <div class="product-img product-img-zoom">
                                                <a href="<?php echo e(route('details', ['slug' => $product->model->slug])); ?>"  wire:navigate>
                                                    <img class="default-img" src="<?php echo e($product->model->image); ?>" alt="">
                                                    <img class="hover-img" src="assets/imgs/shop/product-2-2.jpg" alt="">
                                                </a>
                                            </div>
                                            <div class="product-badges product-badges-position product-badges-mrg">
                                                <span class="hot">Hot</span>
                                            </div>
                                        </div>
                                        <div class="product-content-wrap">
                                            <div class="product-category">
                                                <a href="shop.html">Music</a>
                                            </div>
                                            <h2><a href="product-details.html"><?php echo e($product->model->name); ?></a></h2>
                                            <div class="rating-result" title="90%">
                                                <span>
                                                    <span>90%</span>
                                                </span>
                                            </div>
                                            <div class="product-price">
                                                <span>$<?php echo e($product->model->sale_price); ?> </span>
                                                <span class="old-price">$<?php echo e($product->model->regular_price); ?></span>
                                            </div>
                                            <div class="product-action-1 show">
                                                <a aria-label="Rétirer aux favoris" class="action-btn hover-up" wire:click.prevent="deleteToWishlist(<?php echo e($product->id); ?>)">
                                                    <i class="fi-rs-heart"></i></a>
                                                <a aria-label="Ajouter au panier" class="action-btn hover-up" wire:click.prevent="addToCart('<?php echo e($product->model->id); ?>','<?php echo e(addslashes($product->model->name)); ?>', 1, <?php echo e($product->model->sale_price); ?>)"><i class="fi-rs-shopping-bag-add"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <h5>Aucun produit trouvé</h5>

                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/wishlist-component.blade.php ENDPATH**/ ?>