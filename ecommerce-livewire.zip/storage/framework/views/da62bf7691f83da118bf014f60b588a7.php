<form action="<?php echo e(route('product.search')); ?>">
    <input type="text" name="search" wire:model='search' value="<?php echo e($search); ?>" placeholder="Rechercher par produit...">
    <button type="submit"><i class="fi-rs-search"></i></button>
</form>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/search-header-component.blade.php ENDPATH**/ ?>