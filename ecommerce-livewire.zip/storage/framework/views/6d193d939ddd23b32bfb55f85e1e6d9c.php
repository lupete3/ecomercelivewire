<!-- Add Shipping Adress Model-->
<div class="modal fade " wire:ignore.self id="addSliderModal" tabindex="-1" aria-labelledby="sliderModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e($form_title); ?></h5>
                <button type="button" class="btn-close" wire:click.prevent='hideAddSliderModal'></button>
            </div>
            <div class="modal-body">
                <form method="post" class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Titre de haut</label>
                            <!--[if BLOCK]><![endif]--><?php if($editForm): ?>
                                <input type="hidden" class="form-control" wire:model='idSlide'>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <input type="text" class="form-control" wire:model='top_title' wire:keyup='generateSlug' id="recipient-name">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['top_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" wire:model='slug' id="recipient-name" placeholder="Slug">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label for="">Titre principal</label>
                            <input type="text" class="form-control" wire:model='title' id="recipient-name" placeholder="Entrez le titre principal">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label for="">Sous titre</label>
                            <input type="text" class="form-control" wire:model='sub_title' id="recipient-name" placeholder="Entrez le sous titre">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['sub_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label for="">Pourcentage de l'offre</label>
                            <input type="text" class="form-control" wire:model='offer' id="recipient-name" placeholder="Entrez le pourcentage de l'offre">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['offer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="form-group">
                            <label for="">Lien du slider</label>
                            <input type="text" wire:model='link' class="form-control" id="recipient-name" placeholder="Entrez le lien du slider">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="">Image du slider</label>
                            <input type="file" wire:model='image' class="form-control" id="recipient-name" placeholder="">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($image): ?>
                            <img src="<?php echo e($image->temporaryUrl()); ?>" alt="" width="200px" class="img-thumbnail"> <br>
                            <?php elseif($new_image): ?>
                            <img src="<?php echo e(asset('admin/slider/'.$new_image)); ?>" alt="" width="200px" class="img-thumbnail"> <br>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        <label for="">Date Début</label>
                        <div class="form-group">
                            <input type="date" wire:model='start_date' class="form-control" id="recipient-name" placeholder="Date Début">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="form-group">
                            <label for="">Date Fin</label>
                            <input type="date" wire:model='end_date' class="form-control" id="recipient-name" placeholder="Date Fin">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="payment_method">

                            <div class="icheck-material-orange icheck-inline">
                                <input type="radio" id="someRadioId1" name="someGroupName" value="1" wire:ignore wire:model='status' />
                                <label for="someRadioId1">Actif</label>
                            </div>
                            <div class="icheck-material-orange icheck-inline">
                                <input type="radio" id="someRadioId2" name="someGroupName" value="0" wire:ignore wire:model='status' />
                                <label for="someRadioId2">Inactif</label>
                            </div>

                        </div>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-center"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]--> <br>
                    </div>

            </div>
            <div class="modal-footer">
                <!--[if BLOCK]><![endif]--><?php if($editForm): ?>
                    <button type="button" wire:click.prevent='hideAddSliderModal' class="btn btn-fill-out btn-block btn-sm btn-secondary">Fermer</button>
                    <button type="submit" wire:click.prevent='updateSlider' class="btn btn-fill-out btn-block btn-sm btn-warning">Modifier</button>
                <?php else: ?>
                    <button type="button" wire:click.prevent='hideAddSliderModal' class="btn btn-fill-out btn-block btn-sm btn-secondary" >Fermer</button>
                    <button type="submit" wire:click.prevent='addSlider' class="btn btn-fill-out btn-block btn-sm btn-warning">Ajouter</button>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div></form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/admin/slider/add-slider-modal.blade.php ENDPATH**/ ?>