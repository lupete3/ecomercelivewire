<!-- Edit Shipping Adress Model-->
<div class="modal fade" wire:ignore.self id="editShippingModal" tabindex="-1" aria-labelledby="shippingModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Information de livraison</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post">
                    <div class="radio-inputs mb-2">

                        <label>
                            <input class="radio-input" type="radio" wire:model="adress_type" value="Domicile" wire:ignore>
                            <span class="radio-tile">
                                <span class="radio-icon">
                                    <i class="fi-rs-home" style="font-size:30px"></i>
                                </span>
                                <span class="radio-label">Domicile</span>
                            </span>
                        </label>

                        <label>
                            <input class="radio-input" type="radio" wire:model="adress_type" value="Bureau" wire:ignore>
                            <span class="radio-tile">
                                <span class="radio-icon">
                                    <i class="fi-rs-home" style="font-size:30px"></i>
                                </span>
                                <span class="radio-label">Bureau</span>
                            </span>
                        </label>

                        <label>
                            <input class="radio-input" type="radio" wire:model="adress_type" value="Autre" wire:ignore>
                            <span class="radio-tile">
                                <span class="radio-icon">
                                    <i class="fi-rs-home" style="font-size:30px"></i>
                                </span>
                                <span class="radio-label">Autre</span>
                            </span>
                        </label>

                    </div>
                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adress_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger text-center"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                    <div class="form-group">
                        <input type="text" class="form-control" wire:model='name' values="<?php echo e($name); ?>" id="recipient-name" placeholder="Entrez votre nom complet">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                    <div class="form-group">
                        <input type="number" class="form-control" wire:model='phone' id="recipient-name" placeholder="Entrez votre numéro de téléphone">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" wire:model='email' id="recipient-name" placeholder="Entrez votre adresse mail">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <select name="" wire:model='city' id="" class="form-control">
                            <option value="">Choisir votre ville</option>
                            <option value="Bukavu">Bukavu</option>
                            <option value="Goma">Goma</option>
                            <option value="Kamituga">Kamituga</option>
                            <option value="Uvira">Uvira</option>
                            <option value="Lubumbashi">Lubumbashi</option>
                        </select>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="form-group">
                        <input type="text" wire:model='adress' class="form-control" id="recipient-name" placeholder="Entrez votre adresse de livraison">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['adress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-fill-out btn-block btn-sm btn-secondary" data-bs-dismiss="modal" aria-label="Close">Fermer</button>
                <button type="submit" wire:click.prevent='updateShipping' class="btn btn-fill-out btn-block btn-sm btn-primary">Mettre à jour</button>
            </div></form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Placide\Herd\ecommerce-livewire\resources\views/livewire/partials/shipping/edit-shipping-modal.blade.php ENDPATH**/ ?>